
import React from 'react';

function App() {
  return (
    <div style={{ textAlign: 'center', padding: '50px' }}>
      <h1>Simcha Cards Site</h1>
      <p>Welcome to your custom Simcha invitation platform!</p>
    </div>
  );
}

export default App;
